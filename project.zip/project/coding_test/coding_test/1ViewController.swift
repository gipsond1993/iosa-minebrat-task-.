//
//  1ViewController.swift
//  coding_test
//
//  Created by Gipson on 30/05/25.
//

import UIKit

class _ViewController: UIViewController {

    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var search: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        search.layer.cornerRadius = 8
        search.clipsToBounds = true
        
        button1.layer.cornerRadius = 8
        button1.layer.masksToBounds = true
        
    }
    

    @IBAction func button(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let nextVC = storyboard.instantiateViewController(withIdentifier: "second") as? secondViewController {
                navigationController?.pushViewController(nextVC, animated: true)
            }
        
        
        print("hai")
    }
    

}
