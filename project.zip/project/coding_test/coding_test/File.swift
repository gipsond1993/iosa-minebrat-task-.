//
//  File.swift
//  coding_test
//
//  Created by Gipson on 30/05/25.
//

import Foundation
import UIKit

struct GitHubUser: Codable {
    let login: String
    let id: Int
    let avatar_url: String
    let html_url: String
    let name: String?
    let company: String?
    let blog: String?
    let location: String?
    let bio: String?
    let public_repos: Int
    let followers: Int
    let following: Int
    let created_at: String
}

