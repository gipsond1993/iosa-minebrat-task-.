//
//  TableViewCell.swift
//  coding_test
//
//  Created by Gipson on 30/05/25.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var colour_view: UIView!
    @IBOutlet weak var publicview: UIView!
    @IBOutlet weak var cellview: UIView!
    @IBOutlet weak var name4: UILabel!
    @IBOutlet weak var name3: UILabel!
    @IBOutlet weak var name2: UILabel!
    @IBOutlet weak var name1: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
