//
//  ViewController.swift
//  coding_test
//
//  Created by Gipson on 30/05/25.
//

import UIKit

class secondViewController: UIViewController {
    
    
    @IBOutlet weak var tableview1: UITableView!
    let data = ["Apple", "Banana", "Cherry"]
    @IBOutlet weak var image11: UIImageView!
    
    @IBOutlet weak var following: UILabel!
    @IBOutlet weak var followers: UILabel!
    @IBOutlet weak var name1: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var view_1: UIView!
    @IBOutlet weak var viewimage: UIView!
    @IBOutlet weak var link: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchGitHubUser(username: "dumparun")
        
        
        viewimage.layer.cornerRadius = 35
        viewimage.layer.masksToBounds = true
        
        view_1.layer.cornerRadius = 15
        view_1.layer.masksToBounds = true
        
        
     
        tableview1.delegate = self
        
        
        if tableview1 == nil {
                print("🚨 tableView is nil!")
            } else {
                print("✅ tableView is connected.")
            }
        }
        
    
    
    
    
    
    
    
    func fetchGitHubUser(username: String) {
            let urlString = "https://api.github.com/users/\(username)"
            guard let url = URL(string: urlString) else {
                print("Invalid URL")
                return
            }

            
            URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
                guard let self = self else { return }

                if let error = error {
                    print("Network error: \(error.localizedDescription)")
                    return
                }

                guard let data = data else {
                    print("No data received")
                    return
                }

                do {
                    let user = try JSONDecoder().decode(GitHubUser.self, from: data)
                    DispatchQueue.main.async {
                        self.name.text = user.name ?? "N/A"
                        self.name1.text = user.login
                        self.link.text = (user.blog?.isEmpty == false) ? user.blog : user.html_url
                        self.followers.text = "\(user.followers) Followers"
                        self.following.text = "\(user.following) Following"

                        self.loadImage(from: user.avatar_url, into: self.image11)
                    }
                } catch {
                    print("Decoding error: \(error.localizedDescription)")
                }
            }.resume()
        
        
    }
    
    func loadImage(from urlString: String, into imageView: UIImageView) {
        guard let url = URL(string: urlString) else {
            print("Invalid image URL")
            return
        }
        
        DispatchQueue.main.async {
            self.image11.image = nil
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Image download error: \(error.localizedDescription)")
                return
            }
            guard let data = data, let image = UIImage(data: data) else {
                print("Invalid image data")
                return
            }
            DispatchQueue.main.async {
                self.image11.image = image
            }
        }.resume()
    }
    
}


extension secondViewController : UITableViewDataSource, UITableViewDelegate {
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? TableViewCell else {
            return UITableViewCell()
        }
        
        cell.name1.text = "Cordova - android"
            cell.name2.text = " foaked from apachecordova-android"
            cell.name3.text = "Mirror of apachecordova-android"
            cell.name4.text = "Java"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}


